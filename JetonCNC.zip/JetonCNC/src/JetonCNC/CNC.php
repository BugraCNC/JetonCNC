<?php

namespace JetonCNC;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\{Player, Server};
use pocketmine\command\{Command, CommandSender, ConsoleCommandSender};
use onebone\economyapi\EconomyAPI;
use pocketmine\item\Item;
use pocketmine\event\Listener;
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use korado531m7\InventoryMenuAPI\InventoryMenu;
use korado531m7\InventoryMenuAPI\event\InventoryClickEvent;
use korado531m7\InventoryMenuAPI\event\InventoryCloseEvent;
use korado531m7\InventoryMenuAPI\inventory\DoubleChestInventory;
use korado531m7\InventoryMenuAPI\InventoryType;

class CNC extends PluginBase implements Listener{
	
	public function onEnable(){
		@mkdir($this->getDataFolder());
		$this->config = new Config($this->getDataFolder()."config.yml", Config::YAML);
		$this->getServer()->getPluginManager()->registerEvents ($this, $this);
		$this->getLogger()->info("JetonCNC - BugraCNC");
	}
	
	   public function onCommand(CommandSender $oyuncu, Command $kmt, string $label, array $args): bool{
		   switch($kmt->getName()){
			    case "jetonum":
				     if($oyuncu instanceof Player){
					    if(!($this->config->get($oyuncu->getName()) == null)){
						$this->jetonum($oyuncu);
					    }else{
					    $oyuncu->sendMessage("§cHiç jetonun yok.");
					    }
					    break;
					}

				    case "jver":
			   	        if(!(empty($args[0]) and empty($args[1]))){
			  	        if(is_numeric($args[1])){
			  	        if($oyuncu->isOp()){
			  	        $jeton = (int)$args[1];
					    $this->jetonver($this->getServer()->getPlayer($args[0]), $jeton);
					    $oyuncu->sendMessage($jeton . " §cJeton Verildi !");
				    	}else{
				    	$oyuncu->sendMessage("§cBu komutu kullanmak için yetkin yok.");
				    	}
				    	}else{
				    	$oyuncu->sendMessage("§cMiktar giriniz.");
				    	}
				        }else{
				    	$oyuncu->sendMessage("§cKullanım: §7/jetonver <nick> <adet>");
				      	}
			 	     	break;

				    case "jzenginler":
			  	    	if(isset($args[0])){
 	        	        $maksimum = 0;
              	        $c = $this->config->getAll();
		  		    	$maksimum = count($c);
					    $maksimum = ceil(($maksimum / 5));
				    	$sayfa = array_shift($args);
				    	$sayfa = max(1, $sayfa);
				    	$sayfa = min($maksimum, $sayfa);
				    	$sayfa = (int)$sayfa;
				    	$oyuncu->sendMessage("§cJeton Zenginler §8(§c" . $sayfa."§8/§c".$maksimum."§8)");
				    	$aaa = $this->config->getAll();
				    	arsort($aaa);
				    	$i = 0;
				    	foreach($aaa as $b=>$a){
				    	if(($sayfa - 1) * 5 <= $i && $i <= ($sayfa - 1) * 5 + 4){
					    $i1 = $i + 1;
					    $oyuncu->sendMessage("§e ".$i1." §8»§c ".$b." §8» §6 ".$a);
				    	}
					    $i++;
					    }
					    }else {
			        	$oyuncu->sendMessage("§cKullanım: §7/jetonzenginler <1.2.3.4.5...>");
					    }
                        break;

                    case "jetonu":
                		if(!(empty($args[0]))){
				        $this->jetonu($this->getServer()->getPlayer($args[0]), $oyuncu);
			            }else{
			         	$oyuncu->sendMessage("§cKullanımı: §7/jetonu <nick>");
		             	}
		                break;

				    case "jkes":
			  	        if($oyuncu->isOp()){
					    if(!(empty($args[0]) and empty($args[1]))){
				    	if(is_numeric($args[1])){
					    if(!$this->config->get($this->getServer()->getPlayer($args[0])->getName() == null)){
				    	$jeton = (int)$args[1];
				    	$this->jetonkes($this->getServer()->getPlayer($args[0]), $jeton);
					    $oyuncu->sendMessage("§7Başarıyla §c".$jeton." §7Jeton Kesildi");
				    	}else{
				        $oyuncu->sendMessage("§7oyuncu bulunamadı.");
			        	}
				    	}else{
				    	$oyuncu->sendMessage("§cAlacagınız jeton miktarını yazınız.");
			        	}
				    	}else{
				    	$oyuncu->sendMessage("§cKullanım: §7/jetonkes <isim> <miktar>");
				    	}
			 	        }else{
				    	$oyuncu->sendMessage("§cBu komutu kullanmak için yetkin yok.");
				        }
		    	        break;

		            case "jmarket":
				    $item = [14 => Item::get(310,0,1)->setCustomName("§cEfsanevi Kask\n§75 Jeton"), 23 => Item::get(311,0,1)->setCustomName("§cEfsanevi Göğüslük\n§75 Jeton"), 32 => Item::get(312,0,1)->setCustomName("§cEfsanevi Pantalon\n§75 Jeton"),41 => Item::get(313,0,1)->setCustomName("§cEfsanevi Ayakkabı\n§75 Jeton"), 11 => Item::get(276,0,1)->setCustomName("§cEfsanevi Kılıç\n§715 Jeton"), 20 => Item::get(279,0,1)->setCustomName("§cEfsanevi Balta\n§715 Jeton"), 38 => Item::get(277,0,1)->setCustomName("§cEfsanevi Kürek\n§710 Jeton"), 29 => Item::get(278)->setCustomName("§cEfsanevi Kazma\n§715 Jeton"), 0 => Item::get(444)->setCustomName("§cEfsanevi Elytra\n§73 Jeton")];
		              	$menu = new DoubleChestInventory();
				        $menu->setContents($item);
				        $menu->setName("Jeton Market");
				        $menu->send($oyuncu);
				    	break;
			        }
	       	return true;
	          }

			public function onClicked(InventoryClickEvent $event){
			    $oyuncu = $event->getPlayer();
			    $inv = $event->getInventory();
			    $item = $event->getItem();
			       switch($inv->getTitle()){
			        	case "Jeton Market":
	                        if($item->getCustomName() == "§cEfsanevi Kılıç\n§715 Jeton") {
				    	    if($this->config->get($oyuncu->getName()) >= 15){
                    	    $this->jetonkes($oyuncu, 15);
					 	    $esya = Item::get(276,0,1);
					 	    $esya->setCustomName("§cEfsanevi Kılıç");
					 	    $büyü1 = Enchantment::getEnchantment(9);
					        $büyü1 = new EnchantmentInstance($büyü1, 10);
					        $büyü2 = Enchantment::getEnchantment(17);
							$büyü2 = new EnchantmentInstance($büyü2, 10);
							$esya->addEnchantment($büyü1);
							$esya->addEnchantment($büyü2);
							$oyuncu->getInventory()->addItem($esya);
					        $oyuncu->sendMessage("§cBaşarı ile§f Efsanevi Kılıç §cAlındı !");
					        } else{
					        $oyuncu->sendMessage("§cYeterli miktarda jetonun yok !");
							}
		   	    	    	break;
	                        }

	                        if($item->getCustomName() == "§cEfsanevi Kazma\n§715 Jeton"){
				    	    if($this->config->get($oyuncu->getName()) >= 15){
                    	    $this->jetonkes($oyuncu, 15);
					 	    $esya = Item::get(278,0,1);
					 	    $esya->setCustomName("§cEfsanevi Kazma");
					 	    $büyü1 = Enchantment::getEnchantment(15);
					        $büyü1 = new EnchantmentInstance($büyü1, 20);
					        $büyü2 = Enchantment::getEnchantment(17);
							$büyü2 = new EnchantmentInstance($büyü2, 20);
							$esya->addEnchantment($büyü1);
							$esya->addEnchantment($büyü2);
							$oyuncu->getInventory()->addItem($esya);
					        $oyuncu->sendMessage("§cBaşarı ile§f Efsanevi Kazma §cAlındı");
					        } else{
					        $oyuncu->sendMessage("§cYeterli miktarda jetonun yok");
							}
		   	    	    	break;
	                       }

	                        if($item->getCustomName() == "§cEfsanevi Balta\n§715 Jeton") {
				    	    if($this->config->get($oyuncu->getName()) >= 15){
                    	    $this->jetonkes($oyuncu, 15);
					 	    $esya = Item::get(279,0,1);
					 	    $esya->setCustomName("§cEfsanevi Balta");
					 	    $büyü1 = Enchantment::getEnchantment(15);
					        $büyü1 = new EnchantmentInstance($büyü1, 7);
					        $büyü2 = Enchantment::getEnchantment(17);
							$büyü2 = new EnchantmentInstance($büyü2, 7);
							$esya->addEnchantment($büyü1);
							$esya->addEnchantment($büyü2);
							$oyuncu->getInventory()->addItem($esya);
					        $oyuncu->sendMessage("§cBaşarı ile§f Efsanevi Balta §cAlındı");
					        } else{
					        $oyuncu->sendMessage("§cYeterli miktarda jetonun yok");
							}
		   	    	    	break;
	                        }

	                        if($item->getCustomName() == "§cEfsanevi Kürek\n§715 Jeton") {
				    	    if($this->config->get($oyuncu->getName()) >= 15){
                    	    $this->jetonkes($oyuncu, 15);
					 	    $esya = Item::get(277,0,1);
					 	    $esya->setCustomName("§cEfsanevi Kürek");
					 	    $büyü1 = Enchantment::getEnchantment(15);
					        $büyü1 = new EnchantmentInstance($büyü1, 10);
					        $büyü2 = Enchantment::getEnchantment(17);
							$büyü2 = new EnchantmentInstance($büyü2, 10);
							$esya->addEnchantment($büyü1);
							$esya->addEnchantment($büyü2);
							$oyuncu->getInventory()->addItem($esya);
					        $oyuncu->sendMessage("§cBaşarı ile§f Efsanevi Kürek §cAlındı");
					        } else{
					        $oyuncu->sendMessage("§cYeterli miktarda jetonun yok");
							}
		   	    	    	break;
	                        }

	                        if($item->getCustomName() == "§cEfsanevi Kask\n§75 Jeton") {
				    	    if($this->config->get($oyuncu->getName()) >= 5){
                    	    $this->jetonkes($oyuncu, 5);
					 	    $esya = Item::get(310,0,1);
					 	    $esya->setCustomName("§cEfsanevi Kask");
							$büyü1 = Enchantment::getEnchantment(0);
				            $büyü1 = new EnchantmentInstance($büyü1, 10);
			                $büyü2 = Enchantment::getEnchantment(17);
			                $büyü2 = new EnchantmentInstance($büyü2, 10);
							$esya->addEnchantment($büyü1);
							$esya->addEnchantment($büyü2);
							$oyuncu->getInventory()->addItem($esya);
					        $oyuncu->sendMessage("§cBaşarı ile§f Efsanevi Kask §cAlındı");
					        } else{
					        $oyuncu->sendMessage("§cYeterli miktarda jetonun yok");
							}
		   	    	    	break;
	                        }

	                        if($item->getCustomName() == "§cEfsanevi Göğüslük\n§75 Jeton") {
				    	    if($this->config->get($oyuncu->getName()) >= 5){
                    	    $this->jetonkes($oyuncu, 5);
					 	    $esya = Item::get(311,0,1);
					 	    $esya->setCustomName("§cEfsanevi Göğüslük");
							$büyü1 = Enchantment::getEnchantment(0);
				            $büyü1 = new EnchantmentInstance($büyü1, 10);
			                $büyü2 = Enchantment::getEnchantment(17);
			                $büyü2 = new EnchantmentInstance($büyü2, 10);
							$esya->addEnchantment($büyü1);
							$esya->addEnchantment($büyü2);
							$oyuncu->getInventory()->addItem($esya);
					        $oyuncu->sendMessage("§cBaşarı ile§f Efsanevi Göğüslük §cAlındı");
					        } else{
					        $oyuncu->sendMessage("§cYeterli miktarda jetonun yok");
							}
		   	    	    	break;
	                        }   

	                        if($item->getCustomName() == "§cEfsanevi Pantalon\n§75 Jeton") {
				    	    if($this->config->get($oyuncu->getName()) >= 5){
                    	    $this->jetonkes($oyuncu, 5);
					 	    $esya = Item::get(312,0,1);
					 	    $esya->setCustomName("§cEfsanevi Pantalon");
							$büyü1 = Enchantment::getEnchantment(0);
				            $büyü1 = new EnchantmentInstance($büyü1, 10);
			                $büyü2 = Enchantment::getEnchantment(17);
			                $büyü2 = new EnchantmentInstance($büyü2, 10);
							$esya->addEnchantment($büyü1);
							$esya->addEnchantment($büyü2);
							$oyuncu->getInventory()->addItem($esya);
					        $oyuncu->sendMessage("§cBaşarı ile§f Efsanevi Pantalon §cAlındı");
					        } else{
					        $oyuncu->sendMessage("§cYeterli miktarda jetonun yok");
							}
		   	    	    	break;
	                        }

	                        if($item->getCustomName() == "§cEfsanevi Ayakkabı\n§75 Jeton") {
				    	    if($this->config->get($oyuncu->getName()) >= 5){
                    	    $this->jetonkes($oyuncu, 5);
					 	    $esya = Item::get(313,0,1);
					 	    $esya->setCustomName("§cEfsanevi Ayakkabı");
							$büyü1 = Enchantment::getEnchantment(0);
				            $büyü1 = new EnchantmentInstance($büyü1, 10);
			                $büyü2 = Enchantment::getEnchantment(17);
			                $büyü2 = new EnchantmentInstance($büyü2, 10);
							$esya->addEnchantment($büyü1);
							$esya->addEnchantment($büyü2);
							$oyuncu->getInventory()->addItem($esya);
					        $oyuncu->sendMessage("§cBaşarı ile§f Efsanevi Ayakkabı §cAlındı");
					        } else{
					        $oyuncu->sendMessage("§cYeterli miktarda jetonun yok");
							}
		   	    	    	break;
	                        }    

if($item->getCustomName() == "§cEfsanevi Elytra\n§73 Jeton") {
				    	    if($this->config->get($oyuncu->getName()) >= 3){
                    	    $this->jetonkes($oyuncu, 3);
					 	    $esya = Item::get(444,0,1);
					 	    $esya->setCustomName("§cEfsanevi Elytra");
							$büyü1 = Enchantment::getEnchantment(0);
				            $büyü1 = new EnchantmentInstance($büyü1, 10);
			                $büyü2 = Enchantment::getEnchantment(17);
			                $büyü2 = new EnchantmentInstance($büyü2, 10);
							$esya->addEnchantment($büyü1);
							$esya->addEnchantment($büyü2);
							$oyuncu->getInventory()->addItem($esya);
					        $oyuncu->sendMessage("§cBaşarı ile§f Efsanevi Elytra §cAlındı");
					        } else{
					        $oyuncu->sendMessage("§cYeterli miktarda jetonun yok");
							}
		   	    	    	break;
	                        }    


}
}	
 /**
  @param $o string|Player
  */

	public function jetonver(Player $o, int $jeton = 0){
		$jetonun = $this->config->get($o->getName());
		if($jetonun == null){
			$jetonun = 0;
		}
		$this->config->set($o->getName(), $jetonun+$jeton);
		$this->config->save();
		$o->sendMessage("§cHesabınıza §f".$jeton." §cJeton Eklendi");
	}

	public function jetonum(Player $o){
		$jetonun = $this->config->get($o->getName());
		$o->sendMessage("§cJetonun:§f ".$jetonun);
		return true;
	}

	
	public function jetonkes(Player $o, int $jeton = 0){
		$this->config->set($o->getName(), $this->config->get($o->getName())-$jeton);
		$this->config->save();
		$o->sendMessage("§cHesabınızdan §f".$jeton." §cJeton Kesildi");
	}	

	public function jetonu(Player $jetonuoyuncu, Player $yazanoyuncu){
		$jetonun = $this->config->get($jetonuoyuncu->getName());
		if($jetonun == null){
			$yazanoyuncu->sendMessage("§cBu oyuncunun jetonu yok.");
		}else{
			$yazanoyuncu->sendMessage("§b".$jetonuoyuncu->getName()." §cJetonu: §f".$jetonun);
		}
		return true;
	}
}